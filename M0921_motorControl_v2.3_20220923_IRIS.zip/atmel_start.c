#include <atmel_start.h>
#include "utils.h"



/**
 * Initializes MCU, drivers and middleware in the project
 **/
void atmel_start_init(void)
{
	system_init();
// 	i2c_init();
// 	mcubus_init();
}
