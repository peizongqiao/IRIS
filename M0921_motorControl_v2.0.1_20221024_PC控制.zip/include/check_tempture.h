/*
 * check_tempture.h
 *
 * Created: 2019/8/23 17:25:03
 *  Author: Ade.tang
 */ 


#ifndef CHECK_TEMPTURE_H_
#define CHECK_TEMPTURE_H_
#include <compiler.h>

void t1(void);

#endif /* CHECK_TEMPTURE_H_ */